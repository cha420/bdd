package com.capg.Entities;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class conferencepojo {
	WebDriver driver;
	@FindBy(id="txtFirstName")
	WebElement firstname;
	@FindBy(how=How.LINK_TEXT,linkText="Next")
	WebElement links;
	@FindBy(id="txtLastName")
	WebElement lastName1;
	@FindBy(id="txtEmail")
	WebElement Email;
	@FindBy(id="txtPhone")
	WebElement contact;
	@FindBy(name="size")
	WebElement noOfPersons;
	@FindBy(name="Address")
	WebElement build;
	@FindBy(name="Address2")
	WebElement Area;
	@FindBy(name="city")
	WebElement City;
	@FindBy(name="state")
	WebElement State;
	@FindBy(name="memberStatus")
	WebElement memberStatus;
	
	public WebElement getLastName() {
		return lastName1;
	}
	
	public void setLastName(String lastName) {
		lastName1.sendKeys(lastName);
	}
	public conferencepojo(){
		//driver =log;
		//PageFactory.initElements(driver, this);
	}
	public void conferencepojo1(){
		
	}
	public WebElement getUsername() {
		return firstname;
	}
	public void setUsername(String first) {
		firstname.sendKeys(first);
	}
	public WebElement getLinks() {
		return links;
	}
	public void Links() {
		this.links.click();
	}
	public WebElement getEmail() {
		return Email;
	}
	public void setEmail(String  email) {
	Email.sendKeys(email);
	
	}
	public WebElement getContact() {
		return contact;
	}
	public void setContact() {
		contact.clear();
	}
	public void setContact1(String con) {
		contact.sendKeys(con);
	}
	public WebElement getNoOfPersons() {
		return noOfPersons;
	}
	public void setNoOfPersons(String nop) {
		new Select(this.noOfPersons).selectByVisibleText(nop);
	}
	public WebElement getBuild() {
		return build;
	}
	public void setBuild(String build) {
		this.build.sendKeys(build);
	}

	public WebElement getArea() {
		return Area;
	}

	public void setArea(String area) {
		this.Area.sendKeys(area);
	}

	public WebElement getCity() {
		return City;
	}

	public void setCity(String city) {
		new Select(this.City).selectByVisibleText(city);
	}

	public WebElement getState() {
		return State;
	}

	public void setState(String state) {
	this.State.sendKeys(state);
	}

	public WebElement getStatus() {
		return memberStatus;
	}

	public void setStatus(String status) {
		
		this.memberStatus.click();
	}
	
	

}
